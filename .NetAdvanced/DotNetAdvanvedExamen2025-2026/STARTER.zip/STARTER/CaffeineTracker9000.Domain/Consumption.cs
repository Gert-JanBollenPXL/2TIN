namespace CaffeineTracker9000.Domain;

public class Consumption
{
    public int Id { get; set; }

    public string UserName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public DateTime Time { get; set; } = DateTime.UtcNow;

    public int DrinkId { get; set; }
    public Drink? Drink { get; set; }

}

