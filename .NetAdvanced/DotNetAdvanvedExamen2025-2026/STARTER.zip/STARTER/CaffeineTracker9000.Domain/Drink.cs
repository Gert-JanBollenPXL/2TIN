namespace CaffeineTracker9000.Domain;

public class Drink
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int CaffeineMgPerServing { get; set; }

    public ICollection<Consumption> Consumptions { get; set; } = new List<Consumption>();

}



