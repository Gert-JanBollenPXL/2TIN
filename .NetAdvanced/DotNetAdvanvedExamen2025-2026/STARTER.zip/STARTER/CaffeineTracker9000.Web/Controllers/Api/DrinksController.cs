using CaffeineTracker9000.Domain;
using CaffeineTracker9000.Web.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace CaffeineTracker9000.Web.Controllers.Api;

[ApiController]
public class DrinksController
{
    /*
        POST
     Add a new drink to the system using a repository that implements IDrinkRepository.
     Accepts a DrinkCreateDto object in the request body and returns the created Drink object.
     Use attribute-based routing. This action should be accessible via a POST request to /api/drinks.
     */
    /*public ActionResult<Drink> PostDrink([FromBody] DrinkCreateDto dto)
    {
        throw new NotImplementedException();
    }*/

    /*
        GET
     Retrieve a drink by its unique identifier using a repository that implements IDrinkRepository.
     Accepts the drink Id as a route parameter and returns the corresponding Drink object.
     Use attribute-based routing. This action should be accessible via a GET request to /api/drinks/id (id must be a number).
     */
    /*public ActionResult<Drink> GetById(int id)
    {
        throw new NotImplementedException();
    }*/
}

