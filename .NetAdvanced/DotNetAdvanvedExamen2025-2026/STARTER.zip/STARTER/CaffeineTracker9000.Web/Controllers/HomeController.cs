using CaffeineTracker9000.AppLogic;
using CaffeineTracker9000.Infrastructure;
using CaffeineTracker9000.Web.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CaffeineTracker9000.Controllers;

public class HomeController : Controller
{
    public HomeController()
    {
    }

    public IActionResult Index()
    {
        ConsumptionRepository repo = new ConsumptionRepository();
        var consumptionToday = repo.GetConsumptionOfToday();
        CaffeineTrackerService service = new CaffeineTrackerService();
        CaffeineWarningViewModel? vm = null;
        if (consumptionToday > 0)
        {
            vm = new CaffeineWarningViewModel(consumptionToday, service.DailyDoseToDangerLevel(consumptionToday));
        }
        return View(vm);
    }

    public IActionResult Privacy()
    {
        return View();
    }
}
