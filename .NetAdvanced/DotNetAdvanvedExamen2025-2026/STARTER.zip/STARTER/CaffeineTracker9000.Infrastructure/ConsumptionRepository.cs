using CaffeineTracker9000.AppLogic;
using CaffeineTracker9000.Domain;

namespace CaffeineTracker9000.Infrastructure;

public class ConsumptionRepository : IConsumptionRepository
{
    public void Add(Consumption consumption)
    {
        throw new NotImplementedException();
    }

    public int GetConsumptionOfToday()
    {
        // USE the QUERY syntax
        // Calculate the total intake of Caffeine TODAY
        // TIP: You can use 'DateTime.Today' to get the current date
        return 1230;
    }
}

