using CaffeineTracker9000.AppLogic;
using CaffeineTracker9000.Domain;
using Microsoft.EntityFrameworkCore;

namespace CaffeineTracker9000.Infrastructure;

public class DrinkRepository : IDrinkRepository
{
    public List<Drink> GetAll()
    {   // get all drinks WITH consumptions
        throw new NotImplementedException();
    }

    public Drink? GetById(int id)
    {
        // get a drink by id WITH consumptions
        throw new NotImplementedException();
    }

    public void Add(Drink drink)
    {
        throw new NotImplementedException();
    }
}

