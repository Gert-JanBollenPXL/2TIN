package be.pxl.birdwatchingapi_pe.api;

public class UserUpdateDto {

    private String email;
    private String password;

    public UserUpdateDto() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

