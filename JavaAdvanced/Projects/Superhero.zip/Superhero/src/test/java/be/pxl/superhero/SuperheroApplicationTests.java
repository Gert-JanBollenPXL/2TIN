package be.pxl.superhero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperheroApplicationTests {

    @Test
    void contextLoads() {
    }

}
