package be.pxl.student.eventplatform.domain;

//TODO vul de klasse aan zoals beschreven in de opdracht

public class Attendee {

    // Aanvullend op de oorspronkelijke opgave. Lijst van registraties voor deze attendee is hier niet noodzakelijk
    // List<Registration> registrations;

}
