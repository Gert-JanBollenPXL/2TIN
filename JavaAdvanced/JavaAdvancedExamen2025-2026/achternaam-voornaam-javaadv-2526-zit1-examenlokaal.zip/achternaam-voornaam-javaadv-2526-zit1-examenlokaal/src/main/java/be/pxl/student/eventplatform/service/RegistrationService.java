package be.pxl.student.eventplatform.service;

//TODO vul de klasse aan

public class RegistrationService {

}
