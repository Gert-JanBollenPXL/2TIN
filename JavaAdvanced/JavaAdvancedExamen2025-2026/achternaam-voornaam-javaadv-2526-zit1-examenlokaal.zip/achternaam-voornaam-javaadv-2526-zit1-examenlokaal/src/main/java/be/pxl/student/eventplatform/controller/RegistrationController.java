package be.pxl.student.eventplatform.controller;

//TODO vul de klasse aan en implementeer de endpoints zoals beschreven in de opdracht

public class RegistrationController {

    //TODO USER STORY 3 — Inschrijven op een event

}
