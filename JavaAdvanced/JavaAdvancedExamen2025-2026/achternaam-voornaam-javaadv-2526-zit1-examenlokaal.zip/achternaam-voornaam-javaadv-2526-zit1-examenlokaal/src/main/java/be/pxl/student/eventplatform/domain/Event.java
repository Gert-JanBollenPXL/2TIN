package be.pxl.student.eventplatform.domain;

//TODO vul de klasse aan zoals beschreven in de opdracht

import java.util.List;

public class Event {

    // Aanvullend op de oorspronkelijke opgave (relatie)
    private List<Registration> registrations;

    //TODO 1 Berken de beschikbare plaatsen op basis van de registraties
    // Business rule: bezette plaatsen = aantal registraties met status RESERVED of CHECKED_IN
    // CANCELLED registraties tellen niet mee.
    //TODO 2 UNIT TEST deze methode
    public int availableSeats() {
        return 0; // tijdelijke return om compileerfouten te vermijden
    }


}
