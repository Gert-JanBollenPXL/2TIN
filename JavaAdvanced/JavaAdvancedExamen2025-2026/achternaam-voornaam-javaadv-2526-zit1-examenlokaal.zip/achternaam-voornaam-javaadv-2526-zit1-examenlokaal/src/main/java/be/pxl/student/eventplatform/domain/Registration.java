package be.pxl.student.eventplatform.domain;

//TODO vul de klasse aan zoals beschreven in de opdracht

public class Registration {

    public Registration() {
    }

    //TODO 1 Check-in een registratie
    // Check-in kan enkel wanneer status RESERVED is. Indien niet moet de foutmelding "Check-in not allowed" optreden.
    // Bij check-in wordt status CHECKED_IN en checkedInAt wordt gezet.
    // TIP: Huidige datum en tijd kan bekomen worden via LocalDateTime.now()
    //TODO 2 UNIT TEST deze methode
    public void checkIn() {

    }

}
