package be.pxl.student.eventplatform.controller;

//TODO vul de klasse aan en implementeer de endpoints zoals beschreven in de opdracht

public class AttendeeController {

    //TODO USER STORY 2 — Attendee aanmaken

}
