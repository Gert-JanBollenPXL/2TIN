package be.pxl.student.eventplatform.controller;

//TODO vul de klasse aan en implementeer de endpoints zoals beschreven in de opdracht

public class EventController {

    //TODO USER STORY 1 - Events raadplegen

    //TODO USER STORY 3 -  Inschrijven op een event

    //TODO USER STORY 5 - Registratiestatistieken opvragen

}
