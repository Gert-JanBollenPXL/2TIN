package be.pxl.student.eventplatform.domain;

//TODO vul de klasse aan

public class RegistrationTest {

    //TODO Test check-in functionaliteit zoals beschreven in de opdracht
    // Zorg ervoor dat alle randgevallen getest worden

}
