package be.pxl.cargo.api;

import be.pxl.cargo.api.request.CreateCargoRequest;
import be.pxl.cargo.api.response.CargoStatistics;
import be.pxl.cargo.service.CargoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cargos")
public class CargoController {

    private final CargoService cargoService;

    public CargoController(CargoService cargoService) {
        this.cargoService = cargoService;
    }

    @PostMapping
    public ResponseEntity<String> addCargo(@RequestBody CreateCargoRequest createCargoRequest) {
        return new ResponseEntity<>(cargoService.createCargo(createCargoRequest), HttpStatus.CREATED);
    }

    @GetMapping("/statistics")
    public CargoStatistics getStatistics() {
    return cargoService.getCargoStatistics();
    }
}
